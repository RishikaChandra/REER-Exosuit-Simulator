classdef REER_GUI_exported < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure            matlab.ui.Figure
        RUNSimulatorButton  matlab.ui.control.Button
        timeSlider          matlab.ui.control.Slider
        timeSliderLabel     matlab.ui.control.Label
        assistSlider        matlab.ui.control.Slider
        assistSliderLabel   matlab.ui.control.Label
        loadSlider          matlab.ui.control.Slider
        loadSliderLabel     matlab.ui.control.Label
        fatigueAxes         matlab.ui.control.UIAxes
        torqueAxes          matlab.ui.control.UIAxes
    end

    % Callbacks that handle component events
    methods (Access = private)

        % Button pushed function: RUNSimulatorButton
        function RUNSimulatorButtonPushed(app, event)
            % 1. Read slider inputs
            mass = app.loadSlider.Value;                % Load weight in kg
            assistRatio = app.assistSlider.Value / 100; % Convert % to decimal
            liftTime = app.timeSlider.Value;            % Lift duration in seconds
            dt = 0.1;                                   % Time step for simulation
            time = 0:dt:liftTime;                       % Time array from 0 to liftTime
            % 2. Joints & moment arms
            joints = {'Knee','Hip','LowerBack'};
            momentArms = [0.4, 0.3, 0.25]; % meters
            colors = {'r','g','b'};         % colors for plots
            % 3. Compute torque over time
            torqueTime = zeros(length(joints), length(time)); % empty array
            for j = 1:length(joints)
                % Force increases linearly during lift
                forceTime = (mass*9.81)*(1-assistRatio) * (time/liftTime);
                torqueTime(j,:) = computeTorque(forceTime, momentArms(j));
            end
            % 4. Compute fatigue
            fatigueVals = zeros(1,length(joints));
            for j = 1:length(joints)
                fatigueVals(j) = fatigueIndex(torqueTime(j,:), dt);
            end
            % 5. Plot torque over time
            cla(app.torqueAxes);           % Clear previous plot
            hold(app.torqueAxes,'on');     
            grid(app.torqueAxes,'on');     
            for j = 1:length(joints)
                plot(app.torqueAxes, time, torqueTime(j,:), 'LineWidth',2,'Color',colors{j});
            end
            xlabel(app.torqueAxes,'Time (s)');
            ylabel(app.torqueAxes,'Torque (Nm)');
            legend(app.torqueAxes,joints,'Location','northeast');
            title(app.torqueAxes,sprintf('Torque Over Time (Assist %.0f%%)', assistRatio*100));
            % 6. Plot fatigue
            cla(app.fatigueAxes);   % Clear previous plot
            bar(app.fatigueAxes, categorical(joints), fatigueVals);
            ylabel(app.fatigueAxes,'Cumulative Fatigue');
            title(app.fatigueAxes,sprintf('Fatigue per Joint (Assist %.0f%%)', assistRatio*100));





        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [100 100 640 480];
            app.UIFigure.Name = 'MATLAB App';

            % Create torqueAxes
            app.torqueAxes = uiaxes(app.UIFigure);
            title(app.torqueAxes, 'torqueAxes')
            zlabel(app.torqueAxes, 'Z')
            app.torqueAxes.Position = [288 292 246 168];

            % Create fatigueAxes
            app.fatigueAxes = uiaxes(app.UIFigure);
            title(app.fatigueAxes, 'fatigueAxes')
            zlabel(app.fatigueAxes, 'Z')
            app.fatigueAxes.Position = [288 129 251 151];

            % Create loadSliderLabel
            app.loadSliderLabel = uilabel(app.UIFigure);
            app.loadSliderLabel.HorizontalAlignment = 'right';
            app.loadSliderLabel.Position = [31 410 58 22];
            app.loadSliderLabel.Text = 'loadSlider';

            % Create loadSlider
            app.loadSlider = uislider(app.UIFigure);
            app.loadSlider.Limits = [10 50];
            app.loadSlider.Position = [100 420 161 3];
            app.loadSlider.Value = 10;

            % Create assistSliderLabel
            app.assistSliderLabel = uilabel(app.UIFigure);
            app.assistSliderLabel.HorizontalAlignment = 'right';
            app.assistSliderLabel.Position = [31 326 66 22];
            app.assistSliderLabel.Text = 'assistSlider';

            % Create assistSlider
            app.assistSlider = uislider(app.UIFigure);
            app.assistSlider.Limits = [0 70];
            app.assistSlider.Position = [119 335 142 3];

            % Create timeSliderLabel
            app.timeSliderLabel = uilabel(app.UIFigure);
            app.timeSliderLabel.HorizontalAlignment = 'right';
            app.timeSliderLabel.Position = [25 219 58 22];
            app.timeSliderLabel.Text = 'timeSlider';

            % Create timeSlider
            app.timeSlider = uislider(app.UIFigure);
            app.timeSlider.Limits = [5 20];
            app.timeSlider.Position = [104 229 157 3];
            app.timeSlider.Value = 5;

            % Create RUNSimulatorButton
            app.RUNSimulatorButton = uibutton(app.UIFigure, 'push');
            app.RUNSimulatorButton.ButtonPushedFcn = createCallbackFcn(app, @RUNSimulatorButtonPushed, true);
            app.RUNSimulatorButton.Position = [43 117 100 22];
            app.RUNSimulatorButton.Text = 'RUN Simulator';

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = REER_GUI_exported

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end